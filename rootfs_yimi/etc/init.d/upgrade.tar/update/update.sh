#!/bin/sh

update_dir="../update/update_file/"

sync

rm /etc/resolv.conf -rf
sync
cp ${update_dir}/resolv.conf   /etc/resolv.conf -rf
cp ${update_dir}/default.script  /usr/share/udhcpc/default.script -rf
sync

echo ARiio5100W4GYM_R100_L4.4V003_YM20190513_Release  > /root/version.txt
sync
echo "update success"

